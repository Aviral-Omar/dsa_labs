#include <math.h>
#include <stdlib.h>
#include "merge.h"

void mergeSort(Record arr[], int left, int right);
