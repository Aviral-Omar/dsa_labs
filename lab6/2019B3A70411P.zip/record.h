#ifndef RECORD_STR
#define RECORD_STR

typedef struct record {
	char name[10];
	float cgpa;
} Record;

#endif
