#include <stdio.h>
#include "record.h"

void merge(Record Ls1[], int sz1, Record Ls2[], int sz2, Record Ls[]);
